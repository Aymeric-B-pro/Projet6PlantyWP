<?php
/**
 * Template Name: Contact
 */


get_header(); ?>

<main id="site-content">
    Nous sommes dans la page contact
</main><!-- #site-content -->

<?php
get_footer();
